import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type VideoStatus = 'idea' | 'script_ready' | 'recording' | 'editing' | 'published';
export type Runtime = 'Short (<2 min)' | 'Medium (2-8 min)' | 'Long (8-20 min)';

export interface Video {
  id: string;
  title: string;
  niche: string;
  runtime: Runtime;
  status: VideoStatus;
  script_content: string;
  notes: string;
  voiceover_url: string;
  voiceover_voice: string;
  created_at: string;
  updated_at: string;
}

export type AssetType = 'footage' | 'image' | 'screen_recording' | 'music' | 'sfx';
export type AssetStatus = 'needed' | 'sourced' | 'ready';

export interface BrollAsset {
  id: string;
  video_id: string;
  label: string;
  source_url: string;
  type: AssetType;
  status: AssetStatus;
  created_at: string;
}

export interface ScriptProject {
  id: string;
  video_id: string;
  script_content: string;
  script_tone: string;
  script_instructions: string;
  voiceover_url: string;
  voiceover_voice: string;
  compiled_video_url: string;
  created_at: string;
}

export const STATUS_ORDER: VideoStatus[] = ['idea', 'script_ready', 'recording', 'editing', 'published'];

export const STATUS_LABELS: Record<VideoStatus, string> = {
  idea: 'Idea',
  script_ready: 'Script Ready',
  recording: 'Recording',
  editing: 'Editing',
  published: 'Published',
};

export const STATUS_COLORS: Record<VideoStatus, string> = {
  idea: 'bg-ink-600 text-slate-300',
  script_ready: 'bg-brand-600 text-white',
  recording: 'bg-warning-500 text-white',
  editing: 'bg-accent-500 text-ink-950',
  published: 'bg-success-500 text-white',
};

export const ASSET_TYPE_LABELS: Record<AssetType, string> = {
  footage: 'Footage',
  image: 'Image',
  screen_recording: 'Screen Recording',
  music: 'Music',
  sfx: 'Sound Effect',
};

export const ASSET_STATUS_COLORS: Record<AssetStatus, string> = {
  needed: 'bg-error-500 text-white',
  sourced: 'bg-brand-600 text-white',
  ready: 'bg-success-500 text-white',
};

export const RUNTIME_OPTIONS: Runtime[] = ['Short (<2 min)', 'Medium (2-8 min)', 'Long (8-20 min)'];

export interface ElevenVoice {
  voiceId: string;
  name: string;
  category: string;
  labels?: Record<string, string>;
}

export interface BrollSearchResult {
  id: number;
  width: number;
  height: number;
  duration: number;
  thumbnail: string | null;
  videoUrl: string | null;
}

function edgeUrl(slug: string): string {
  return `${supabaseUrl}/functions/v1/${slug}`;
}

function edgeHeaders(): HeadersInit {
  return {
    Authorization: `Bearer ${supabaseAnonKey}`,
    'Content-Type': 'application/json',
  };
}

export async function generateScript(params: {
  title: string;
  niche: string;
  runtime: Runtime;
  tone?: string;
  instructions?: string;
}): Promise<{ script?: string; error?: string }> {
  try {
    const res = await fetch(edgeUrl('generate-script'), {
      method: 'POST',
      headers: edgeHeaders(),
      body: JSON.stringify(params),
    });
    const data = await res.json();
    if (!res.ok) return { error: data.error ?? 'Script generation failed' };
    return { script: data.script };
  } catch (err) {
    return { error: err instanceof Error ? err.message : 'Network error' };
  }
}

export async function searchBroll(params: {
  query: string;
  perPage?: number;
}): Promise<{ results?: BrollSearchResult[]; error?: string }> {
  try {
    const res = await fetch(edgeUrl('source-broll'), {
      method: 'POST',
      headers: edgeHeaders(),
      body: JSON.stringify(params),
    });
    const data = await res.json();
    if (!res.ok) return { error: data.error ?? 'B-roll search failed' };
    return { results: data.results };
  } catch (err) {
    return { error: err instanceof Error ? err.message : 'Network error' };
  }
}

export async function listVoices(): Promise<{ voices?: ElevenVoice[]; error?: string }> {
  try {
    const res = await fetch(edgeUrl('list-voices'), {
      method: 'POST',
      headers: edgeHeaders(),
    });
    const data = await res.json();
    if (!res.ok) return { error: data.error ?? 'Failed to load voices' };
    return { voices: data.voices };
  } catch (err) {
    return { error: err instanceof Error ? err.message : 'Network error' };
  }
}

export async function generateVoiceover(params: {
  text: string;
  voiceId: string;
  videoId: string;
}): Promise<{ url?: string; error?: string }> {
  try {
    const res = await fetch(edgeUrl('text-to-speech'), {
      method: 'POST',
      headers: edgeHeaders(),
      body: JSON.stringify(params),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) return { error: data.error ?? `Voiceover failed (${res.status})` };
    return { url: data.url };
  } catch (err) {
    return { error: err instanceof Error ? err.message : 'Network error' };
  }
}
